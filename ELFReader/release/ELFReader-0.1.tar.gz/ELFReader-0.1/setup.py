from setuptools import setup

setup(
    name='ELFReader',
    version='0.1',
    py_modules=['ELFReader'],
    install_requires=[
        'pyelftools',
    ],

)
